<?php
// Heading
$_['text_title']			= '<img src="admin/view/image/payment/paymentoption.png" alt="Payment Option" title="SME Dasgateway" style="border: 1px solid #EEEEEE; width:100px;" />';

// Button
$_['button_confirm']			= 'Continue';

// Text

$_['text_card_number']			= 'Credit card number';
$_['text_card_month']			= 'Expiry Month';
$_['text_card_year']			= 'Expiry Year';
$_['text_card_cvv']			= 'CVV';
$_['text_card_name']			= 'Card Holder Name';

// Error
$_['error_failed']			= 'Unable to process your payment, please try again';
$_['curl_error']			= 'Unable to process payment due to server issue. Kindly check with your Merchant(curl)';
