<?php

namespace Opencart\Catalog\Controller\Extension\Dasgateway\Payment;

class Dasgateway extends \Opencart\System\Engine\Controller { 

	public function index() {
		$this->load->language('extension/dasgateway/dasgateway');

		$this->load->model('checkout/order');
		$this->load->model('extension/dasgateway/payment/dasgateway');

		/**Gathering order details*/
		$order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);

		$data['timestamp'] = date('Y:m:d-H:i:s');
		$data['order_id'] = $this->session->data['order_id'];
		$data['continue'] = $this->url->link('checkout/cart');
		
		$data['order_id'] = $this->session->data['order_id'];

		$data["show_button"] = $this->config->get('payment_dasgateway_show_button');
		
		if($this->config->get('payment_dasgateway_payment_type') == 1) {
		    return $this->load->view('extension/dasgateway/dasgateway_hpp', $data);
		}
		else {
		    return $this->load->view('extension/dasgateway/dasgateway', $data);
		}
	}

	/**if not payment is not 3d secure*/
	public function pay() {
	
		$this->load->language('extension/dasgateway/dasgateway');
		$this->load->model('checkout/order');
		$this->load->model('extension/dasgateway/payment/dasgateway');		
		
		if($this->request->server['REQUEST_METHOD'] == 'POST'){
			
			$post_vals = array();
			
			if(1) {
				
				
				if($this->config->get('payment_dasgateway_token') != ''){		
					/** Update to a valid Key */
					$api_key = $this->config->get('payment_dasgateway_token');
					
					$json = [];

					if (!isset($this->session->data['order_id'])) {
						$json['error'] = $this->language->get('error_order');
					}

					if (!isset($this->session->data['payment_method'])) {
						$json['error'] = $this->language->get('error_payment_method');
					}

					if (!$json) {
					
						$order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
						//$this->model_checkout_order->addOrderHistory($order_info['order_id'], $this->config->get('payment_dasgateway_status_id'));

						$comment  = $this->language->get('text_instruction') . "\n\n";
						$comment .= $this->language->get('text_payment');
						$this->model_checkout_order->addHistory($this->session->data['order_id'], $this->config->get('payment_dasgateway_status_id'), $comment, true);
							
						/**insert transaction details to the database*/
						//$insert_trans_details = $this->model_extension_payment_dasgateway->addOrder($trans_token,$merch_trans_ref,$merchant_ip,$auth_code,$pay_token,$amount,$mode,$brand,$card,$status,$created);
							
						$params = array(
							"return_url"=> array(
								"webhook_url"=> $this->url->link('checkout/success', 'language=' . $this->config->get('config_language'), true),
								"success_url"=> $this->url->link('checkout/success', 'language=' . $this->config->get('config_language'), true),
								"decline_url"=> $this->url->link('checkout/failure', 'language=' . $this->config->get('config_language'), true)
							),
							"amount"=> $order_info["total"],
							"currency" => $this->config->get('payment_dasgateway_merchant_currency'),
							"merchant_id"=>  $this->config->get('payment_dasgateway_merchant_id'),
							"merchant_txn_ref"=> $order_info["order_id"],
							"billing_address"=> array(
								"country"     => $order_info["payment_country"],
								"email"       => $order_info["email"],
								"phone"       => $order_info["telephone"],
								"address1"    => $order_info["payment_address_1"],
								"city"        => $order_info["payment_city"],
								"state"       => $order_info["payment_zone"],
								"postal_code" => $order_info["payment_postcode"]
							),
				
							"shipping_address"=> array(
								"country"     => $order_info["shipping_country"],
								"email"       => $order_info["email"],
								"phone"       => $order_info["telephone"],
								"address1"    => $order_info["shipping_address_1"],
								"city"        => $order_info["shipping_city"],
								"state"       => $order_info["shipping_zone"],
								"postal_code" => $order_info["shipping_postcode"]
							),
						);

						$header = array(
							"authorization: BASIC ".$this->config->get('payment_dasgateway_token'),
							"cache-control: no-cache",
							"content-type: application/json",
							"x-api-key: ".$this->config->get('payment_dasgateway_x_api_key')
						);
			
						$ch = curl_init();
			
						curl_setopt_array($ch, array(
							CURLOPT_URL => $this->config->get('payment_dasgateway_das_url'),
							CURLOPT_RETURNTRANSFER => true,
							CURLOPT_ENCODING => "",
							CURLOPT_MAXREDIRS => 10,
							CURLOPT_TIMEOUT => 30,
							CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
							CURLOPT_CUSTOMREQUEST => "POST",
							CURLOPT_POSTFIELDS => json_encode($params),
							CURLOPT_HTTPHEADER => $header,
						));
			
						$response = curl_exec($ch);
						$err = curl_error($ch);
			
						$data = json_decode($response, true);
			
						curl_close($ch);

						/*print "<pre>";
						print_r($params);
						print_r($response);*/

						$json['redirect'] = $data["url"];

					}
				
				} else {
					$this->session->data['error'] = $this->language->get('curl_error');			      
					$json['error'] = $this->language->get('curl_error');
				}				
			} else {
				$this->session->data['error'] = $this->language->get('curl_error');			      
				$json['error'] = $this->language->get('curl_error');
			}
		
		} else {
			$this->session->data['error'] = $this->language->get('curl_error');			      
			$json['error'] = $this->language->get('curl_error');
		}
		
		/**pass the response*/
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	
	public function cc_payment() {

		$this->load->language('extension/dasgateway/dasgateway');
		$this->load->model('checkout/order');
		$this->load->model('extension/dasgateway/payment/dasgateway');;

		$json = [];
		$merchantID = "";

		$order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
		  
		$country = $order_info['payment_iso_code_2'];
		$email = $order_info['email'];
		$amount = $order_info['total'];
		//$currency = $order_info['currency_code'];
		$currency = $this->session->data['currency'];
		$address_1 = $order_info["payment_address_1"];
		$phone = $order_info['telephone'];
		$city = $order_info['payment_city'];
		$postcode = $order_info['payment_postcode'];
		$zone = $order_info['payment_zone'];
		$invoice_ref = $this->config->get('payment_dasgateway_invoice');
		$merchant_ip = $_SERVER['REMOTE_ADDR'];
		$visit_ip = $this->getUserIpAddr();
		$comment = $order_info['comment'];
		
		if($this->request->server['REQUEST_METHOD'] == 'POST') {
			
			$cData = array();
			$cData['number'] = (isset($this->request->post['card_number']))? $this->request->post['card_number']: "";
			$cData['expiry_month'] = (isset($this->request->post['expiry_month']))? $this->request->post['expiry_month']: "";
			$cData['expiry_year'] = (isset($this->request->post['expiry_year']))? $this->request->post['expiry_year']: "";
			$cData['cvc'] = (isset($this->request->post['cvv']))? $this->request->post['cvv']: "";
			$cData['name'] = (isset($this->request->post['name']))? $this->request->post['name']: "";
			$cData['card_type'] = (isset($this->request->post['card_type']))? $this->request->post['card_type']: "";

			if($currency == "JPY") {
				if($cData['card_type'] == "Visa" || $cData['card_type'] == "MasterCard") {
					$merchantID = $this->config->get('payment_dasgateway_jpy_visa_merchant_id');
				}
				else if($cData['card_type'] == "Amex") {
					$merchantID = $this->config->get('payment_dasgateway_jpy_amex_merchant_id');
				}
				else if($cData['card_type'] == "jcb") {
					$merchantID = $this->config->get('payment_dasgateway_jpy_jcb_merchant_id');
				}
			}
			else {
				if($cData['card_type'] == "Visa" || $cData['card_type'] == "MasterCard") {
					$merchantID = $this->config->get('payment_dasgateway_usd_visa_merchant_id');
				}
				else if($cData['card_type'] == "Amex") {
					$merchantID = $this->config->get('payment_dasgateway_usd_amex_merchant_id');
				}
				else if($cData['card_type'] == "jcb") {
					$merchantID = $this->config->get('payment_dasgateway_usd_jcb_merchant_id');
				}
			}

			$url = $this->config->get('payment_dasgateway_das_url');

			$headers = array(
								"Authorization: Basic ".$this->config->get('payment_dasgateway_token'),
								'x-api-key: '.$this->config->get('payment_dasgateway_x_api_key'),
								"Content-Type: application/json"
							);

			$card = array(
						"cvc" => $cData['cvc'],
						"expiry_month" => $cData['expiry_month'],
						"expiry_year" => $cData['expiry_year'],
						"name" => $cData['name'],
						"number" => $cData['number']
					);

			$billing_address = array(
									"country" => $country,
									"email" => $email,
									"address1" => $address_1,
									"phone_number" => $phone,
									"city" => $city,
									"state" => $zone,
									"postal_code" => $postcode
								);

			$shipping_address = array(
									"country" => $country,
									"email" => $email,
									"address1" => $address_1,
									"phone_number" => $phone,
									"city" => $city,
									"state" => $zone,
									"postal_code" => $postcode
								);

			$return_url = array(
							"webhook_url" => "",
							"success_url" => "",
							"decline_url" => ""
						);


			$post_vals = array(
				"amount" => $amount,
				"currency" => $currency,
				"card" => $card,
				"merchant_txn_ref" => $order_info["order_id"],
				"customer_ip" => $visit_ip,
				"merchant_id" => $merchantID,
				"return_url" => $return_url,
				"billing_address" => $billing_address,
				"shipping_address" => $shipping_address,
				"time_zone" => "Asia/Kuala_Lumpur"
			);

			$post_data = json_encode($post_vals);
				
			$curl = curl_init();
			curl_setopt($curl, CURLOPT_URL, $url);
			curl_setopt($curl,CURLOPT_RETURNTRANSFER, TRUE);
			curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
			curl_setopt($curl, CURLOPT_POST, 1);
			curl_setopt($curl, CURLOPT_POSTFIELDS, $post_data);

			$curl_response = curl_exec($curl);

			curl_close ($curl);
			
			$result = json_decode($curl_response);

			/*print "<pre>";
			print_r($result);
			exit();*/

			if($result) {
				if($result->success == 1){
					$trans_token = $result->transaction_details->id;
					$merch_trans_ref = $result->transaction_details->merchant_txn_ref;
					$merchant_ip = "";
					$auth_code = $result->payment_details->auth_code;
					$pay_token = "";
					$amount = $result->payment_details->amount;
					$mode = $result->payment_details->payment_method;
					$brand =  $result->payment_details->scheme;
					$card = $result->payment_details->card->number;
					$status = 'Success';
					$created = $result->transaction_details->timestamp;
					$order_id = $this->session->data['order_id'];
					$message = "";
					
					/** The success transaction log to order table*/
					$order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
					/*$this->model_checkout_order->addOrderHistory($order_info['order_id'], $this->config->get('payment_dasgatewaycc_status_id'));*/
					
					$this->model_checkout_order->addHistory($this->session->data['order_id'], $this->config->get('payment_dasgateway_status_id'), $comment, true);
						
					/**insert transaction details to the database*/
					/*$insert_trans_details = $this->model_extension_payment_dasgateway->addOrder($trans_token,$merch_trans_ref,$merchant_ip,$auth_code,$pay_token,$amount,$mode,$brand,$card,$status,$created);
						
					if($insert_trans_details){
						$json['redirect'] = $this->url->link('checkout/success');				
					}*/
					
					$json['redirect'] = $this->url->link('checkout/success');
						
				} else {
						
					$this->session->data['error'] = $result->gateway_response->message;
					$json['error'] = $result->gateway_response->message;
				}
				
			} else {
				$this->session->data['error'] = $this->language->get('curl_error');
				$json['error'] = $this->language->get('curl_error');
			}

		}

		/**pass the response*/
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	
	public function getUserIpAddr(){
		if(!empty($_SERVER['HTTP_CLIENT_IP'])){
		    //ip from share internet
		    $ip = $_SERVER['HTTP_CLIENT_IP'];
		}elseif(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){
		    //ip pass from proxy
		    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		}else{
		    $ip = $_SERVER['REMOTE_ADDR'];
		}
		return $ip;
	}

}