<?php

namespace Opencart\Catalog\Model\Extension\Dasgateway\Payment;

class Dasgateway extends \Opencart\System\Engine\Model {

	public function getMethods(array $address = []): array {
		//$this->load->language('extension/payment/dasgateway');

		//$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "zone_to_geo_zone WHERE geo_zone_id = '" . (int)$this->config->get('payment_dasgateway_geo_zone_id') . "' AND country_id = '" . (int)$address['country_id'] . "' AND (zone_id = '" . (int)$address['zone_id'] . "' OR zone_id = '0')");

		

		$method_data = array();

		$option_data['dasgateway'] = [
			'code' => 'dasgateway.dasgateway',
			'name' => "Credit Card"
		];

		$method_data = [
			'code'       => 'dasgateway',
			'name'       => "DAS Gateway",
			'option'     => $option_data,
			'sort_order' => $this->config->get('payment_dasgateway_sort_order')
		];
		

		return $method_data;
	}

	public function addOrder($trans_token,$merch_trans_ref,$merchant_ip,$auth_code,$pay_token,$amount,$mode,$brand,$card,$status,$created) {

		$this->db->query("INSERT INTO `" . DB_PREFIX . "dasgateway_order` (`trans_token`, `merch_trans_ref`, `merchant_ip`, `auth_code`, `pay_token`, `amount`, `mode`, `brand`, `card`, `status`, `created`) VALUES ('".$trans_token."','".$merch_trans_ref."','".$merchant_ip."','".$auth_code."','".$pay_token."','".$amount."','".$mode."','".$brand."','".$card."','".$status."','".$created."')");
		
		return true;
	}

	
}