<?php

namespace Opencart\Admin\Controller\Extension\Dasgateway\Payment;

class Dasgateway extends \Opencart\System\Engine\Controller {

	private $error = array();

	public function index() {
		$this->load->language('extension/dasgateway/dasgateway');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('setting/setting');
		
		$this->load->model('localisation/order_status');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$this->model_setting_setting->editSetting('payment_dasgateway', $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true));
		}

		$data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();
		
		$this->load->model('localisation/geo_zone');

		$data['geo_zones'] = $this->model_localisation_geo_zone->getGeoZones();

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['error_secret_key'])) {
			$data['error_secret_key'] = $this->error['error_secret_key'];
		} else {
			$data['error_secret_key'] = '';
		}

		/**breadcrumbs*/
		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/dasgateway/dasgateway', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['action'] = $this->url->link('extension/dasgateway/payment/dasgateway', 'user_token=' . $this->session->data['user_token'], true);
		
		$data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true);

		if (isset($this->request->post['payment_dasgateway_payment_type'])) {
			$data['payment_dasgateway_payment_type'] = $this->request->post['payment_dasgateway_payment_type'];
		} else {
			$data['payment_dasgateway_payment_type'] = $this->config->get('payment_dasgateway_payment_type');
		}

		if (isset($this->request->post['payment_dasgateway_invoice'])) {
			$data['payment_dasgateway_invoice'] = $this->request->post['payment_dasgateway_invoice'];
		} else {
			$data['payment_dasgateway_invoice'] = $this->config->get('payment_dasgateway_invoice');
		}
		
		if (isset($this->request->post['payment_dasgateway_status_id'])) {
			$data['payment_dasgateway_status_id'] = $this->request->post['payment_dasgateway_status_id'];
		} else {
			$data['payment_dasgateway_status_id'] = $this->config->get('payment_dasgateway_status_id');
		}
		
		if (isset($this->request->post['payment_dasgateway_geo_zone_id'])) {
			$data['payment_dasgateway_geo_zone_id'] = $this->request->post['payment_dasgateway_geo_zone_id'];
		} else {
			$data['payment_dasgateway_geo_zone_id'] = $this->config->get('payment_dasgateway_geo_zone_id');
		}
		

		if (isset($this->request->post['payment_dasgateway_sort_order'])) {
			$data['payment_dasgateway_sort_order'] = $this->request->post['payment_dasgateway_sort_order'];
		} else {
			$data['payment_dasgateway_sort_order'] = $this->config->get('payment_dasgateway_sort_order');
		}

		if (isset($this->request->post['payment_dasgateway_status'])) {
			$data['payment_dasgateway_status'] = $this->request->post['payment_dasgateway_status'];
		} else {
			$data['payment_dasgateway_status'] = $this->config->get('payment_dasgateway_status');
		}

		if (isset($this->request->post['payment_dasgateway_3d_secure'])) {
			$data['payment_dasgateway_3d_secure'] = $this->request->post['payment_dasgateway_3d_secure'];
		} else {
			$data['payment_dasgateway_3d_secure'] = $this->config->get('payment_dasgateway_3d_secure');
		}

		if (isset($this->request->post['payment_dasgateway_order_status_void_id'])) {
			$data['payment_dasgateway_order_status_void_id'] = $this->request->post['payment_dasgateway_order_status_void_id'];
		} else {
			$data['payment_dasgateway_order_status_void_id'] = $this->config->get('payment_dasgateway_order_status_void_id');
		}

		if (isset($this->request->post['payment_dasgateway_das_url'])) {
			$data['payment_dasgateway_das_url'] = $this->request->post['payment_dasgateway_das_url'];
		} else {
			$data['payment_dasgateway_das_url'] = $this->config->get('payment_dasgateway_das_url');
		}

		if (isset($this->request->post['payment_dasgateway_token'])) {
			$data['payment_dasgateway_token'] = $this->request->post['payment_dasgateway_token'];
		} else {
			$data['payment_dasgateway_token'] = $this->config->get('payment_dasgateway_token');
		}

		if (isset($this->request->post['payment_dasgateway_merchant_id'])) {
			$data['payment_dasgateway_merchant_id'] = $this->request->post['payment_dasgateway_merchant_id'];
		} else {
			$data['payment_dasgateway_merchant_id'] = $this->config->get('payment_dasgateway_merchant_id');
		}
		
		if (isset($this->request->post['payment_dasgateway_usd_visa_merchant_id'])) {
			$data['payment_dasgateway_usd_visa_merchant_id'] = $this->request->post['payment_dasgateway_usd_visa_merchant_id'];
		} else {
			$data['payment_dasgateway_usd_visa_merchant_id'] = $this->config->get('payment_dasgateway_usd_visa_merchant_id');
		}

		if (isset($this->request->post['payment_dasgateway_usd_amex_merchant_id'])) {
			$data['payment_dasgateway_usd_amex_merchant_id'] = $this->request->post['payment_dasgateway_usd_amex_merchant_id'];
		} else {
			$data['payment_dasgateway_usd_amex_merchant_id'] = $this->config->get('payment_dasgateway_usd_amex_merchant_id');
		}

		if (isset($this->request->post['payment_dasgateway_usd_jcb_merchant_id'])) {
			$data['payment_dasgateway_usd_jcb_merchant_id'] = $this->request->post['payment_dasgateway_usd_jcb_merchant_id'];
		} else {
			$data['payment_dasgateway_usd_jcb_merchant_id'] = $this->config->get('payment_dasgateway_usd_jcb_merchant_id');
		}

		if (isset($this->request->post['payment_dasgateway_jpy_visa_merchant_id'])) {
			$data['payment_dasgateway_jpy_visa_merchant_id'] = $this->request->post['payment_dasgateway_jpy_visa_merchant_id'];
		} else {
			$data['payment_dasgateway_jpy_visa_merchant_id'] = $this->config->get('payment_dasgateway_jpy_visa_merchant_id');
		}

		if (isset($this->request->post['payment_dasgateway_jpy_amex_merchant_id'])) {
			$data['payment_dasgateway_jpy_amex_merchant_id'] = $this->request->post['payment_dasgateway_jpy_amex_merchant_id'];
		} else {
			$data['payment_dasgateway_jpy_amex_merchant_id'] = $this->config->get('payment_dasgateway_jpy_amex_merchant_id');
		}

		if (isset($this->request->post['payment_dasgateway_jpy_jcb_merchant_id'])) {
			$data['payment_dasgateway_jpy_jcb_merchant_id'] = $this->request->post['payment_dasgateway_jpy_jcb_merchant_id'];
		} else {
			$data['payment_dasgateway_jpy_jcb_merchant_id'] = $this->config->get('payment_dasgateway_jpy_jcb_merchant_id');
		}

		if (isset($this->request->post['payment_dasgateway_merchant_currency'])) {
			$data['payment_dasgateway_merchant_currency'] = $this->request->post['payment_dasgateway_merchant_currency'];
		} else {
			$data['payment_dasgateway_merchant_currency'] = $this->config->get('payment_dasgateway_merchant_currency');
		}

		if (isset($this->request->post['payment_dasgateway_x_api_key'])) {
			$data['payment_dasgateway_x_api_key'] = $this->request->post['payment_dasgateway_x_api_key'];
		} else {
			$data['payment_dasgateway_x_api_key'] = $this->config->get('payment_dasgateway_x_api_key');
		}

		if (isset($this->request->post['payment_dasgateway_show_button'])) {
			$data['payment_dasgateway_show_button'] = $this->request->post['payment_dasgateway_show_button'];
		} else {
			$data['payment_dasgateway_show_button'] = $this->config->get('payment_dasgateway_show_button');
		}

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		
		

		$this->response->setOutput($this->load->view('extension/dasgateway/dasgateway', $data));
	}

	/**Module Installation*/
	public function install() {
		$this->load->model('extension/dasgateway/dasgateway');
		$this->model_extension_dasgateway_dasgateway->install();
	}

	/**Module Uninstall function*/
	public function uninstall() {
		$this->load->model('extension/dasgateway/dasgateway');
		$this->model_extension_dasgateway_dasgateway->uninstall();
	}	

	/**Validate Udmin fields*/
	protected function validate() {
		if (!$this->user->hasPermission('modify', 'extension/dasgateway/payment/dasgateway')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}
}