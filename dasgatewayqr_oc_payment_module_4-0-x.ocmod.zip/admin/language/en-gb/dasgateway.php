<?php
// Heading
$_['heading_title']				 = 'Dasgateway';

// Text
$_['text_extension']				 = 'Extensions';
$_['text_success']				 = 'Success: You have modified Dasgateway payment details!';
$_['text_edit']                      		 = 'Edit Dasgateway Payment Module';
$_['text_notification_url']			 = 'Notification URL';
$_['text_order_status']				 = 'Order status';
$_['text_enabled']				 = 'Enabled';
$_['text_secret_key']				 = 'Secret Key';
$_['text_dasgateway']				 = '<img src="view/image/payment/dasgateway.png" alt="dasgateway" title="Dasgateway" style="border: 1px solid #EEEEEE; width:100px;" />';
$_['text_payment_info']				 = 'Payment information';


// Entry
$_['entry_secret_key']				 = 'Secret Key';
$_['entry_invoice']				 = 'Merchant txn. ref.';
$_['entry_sort_order']				 = 'Sort order';
$_['entry_order_status']			 = 'Order Status';
$_['entry_geo_zone']				 = 'Geo zone';
$_['entry_status']				 = 'Status';


// Help
$_['help_invoice']				 = 'A reference for the transaction set by the merchant (ex: invoice number).';
$_['help_order_status']				 = 'Set the default order status when an order is processed. Default is Pending';


// Tab
$_['tab_account']				 = 'API Settings';


// Error
$_['error_secret_key']				 = 'Secret Key issued by Dasgateway is required';
$_['error_invoice']				 = 'Merchant transaction reference (Optional)';
$_['error_data_missing']			 = 'Data missing';
