<?php

namespace Opencart\Admin\Model\Extension\Dasgateway;

class Dasgateway extends \Opencart\System\Engine\Model {
	
	public function install() {
		$this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "dasgateway_order` (
			`id` int(11) NOT NULL AUTO_INCREMENT,
			  `trans_token` varchar(50) NOT NULL,
			  `merch_trans_ref` varchar(30) NOT NULL,
			  `merchant_ip` varchar(30) NOT NULL,
			  `auth_code` varchar(50) NOT NULL,
			  `pay_token` varchar(50) NOT NULL,
			  `amount` int(11) NOT NULL,
			  `mode` int(11) NOT NULL,
			  `brand` varchar(20) NOT NULL,
			  `card` varchar(50) NOT NULL,
			  `status` varchar(20) NOT NULL,
			  `created` varchar(30) NOT NULL,
			  PRIMARY KEY (`id`)
			) ENGINE=MyISAM DEFAULT COLLATE=utf8_general_ci;");

	}

	public function uninstall() {
		$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "dasgateway_order`;");

	}

}